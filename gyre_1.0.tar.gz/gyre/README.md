# gyre
R package to install TeX Gyre fonts with 'extrafont'
