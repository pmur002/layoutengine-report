
.onLoad <- function(libname, pkgname) {
    options(layoutEngine.backend=DOMEngine)
}
