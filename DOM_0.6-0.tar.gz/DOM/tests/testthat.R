library(testthat)
library("DOM")

test_check("DOM")
