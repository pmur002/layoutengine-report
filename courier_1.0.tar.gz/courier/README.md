# courier
R package to install IBM Courier fonts with 'extrafont' 
