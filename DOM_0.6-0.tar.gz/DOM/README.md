# DOM

[![Build Status](https://travis-ci.org/pmur002/DOM.svg?branch=master)](https://travis-ci.org/pmur002/DOM)
[![Coverage Status](https://codecov.io/github/pmur002/DOM/coverage.svg?branch=master)](https://codecov.io/github/pmur002/DOM)

Drive web browser content from R

